package PrimeiroProjetoDeAbertura.Projeto.de.abertura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoDeAberturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoDeAberturaApplication.class, args);
	}

}
